This is a text file inside a zip archive.
The zip contains sample data for testing.
